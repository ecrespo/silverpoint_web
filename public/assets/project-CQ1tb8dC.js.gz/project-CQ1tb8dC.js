import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{o as t,t as n}from"./state-ZDHr06r7.js";import{r}from"./context-DliHR4oJ.js";import{G as i}from"./components-BRno7RdY.js";import{n as a}from"./emotion-react.browser.esm-BSmvw_3e.js";var o=e(i(),1),s=(()=>{let e=(0,o.memo)(({children:e,...i})=>{let s=(0,o.useCallback)((e=>r([n(`_call_function`,{function:(()=>navigator?.clipboard?.writeText(`pip install reflex-silverpoint-react
# or
uv add reflex-silverpoint-react`)),callback:null},{})],[e],{})),[]);return a(`button`,{...t(i,{className:`spw-copy`,onClick:s,title:`Copy to clipboard`,type:`button`})},e)});return e.displayName=`Button`,e})(),c=(()=>{let e=(0,o.memo)(({children:e,...i})=>{let s=(0,o.useCallback)((e=>r([n(`_call_function`,{function:(()=>navigator?.clipboard?.writeText(`**Package and version:** @silverpoint/react@0.10.1
**Framework and version:** (React 19.x / Vue 3.5.x / Angular 22.x / Reflex 0.11.x)
**Integration:** (Vite / Next.js / Angular CLI / Reflex)
**Chart or UI component:** (e.g. LineChart, SpTabs)
**Ground / substrate / mode:** (silverpoint / cream / ink)
**Browser and OS:**

### What happened


### What you expected


### Minimal reproduction
(A few lines of code, a StackBlitz, or a repository.)

### Diagnostic codes in the console (SP0xx), if any
`)),callback:null},{})],[e],{})),[]);return a(`button`,{...t(i,{className:`spw-copy`,onClick:s,title:`Copy to clipboard`,type:`button`})},e)});return e.displayName=`Button`,e})(),l=(()=>{let e=(0,o.memo)(({children:e,...i})=>{let s=(0,o.useCallback)((e=>r([n(`_call_function`,{function:(()=>navigator?.clipboard?.writeText(`MIT License

Copyright (c) 2026 Ernesto Crespo

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the conditions of the license.`)),callback:null},{})],[e],{})),[]);return a(`button`,{...t(i,{className:`spw-copy`,onClick:s,title:`Copy to clipboard`,type:`button`})},e)});return e.displayName=`Button`,e})();export{s as n,l as r,c as t};